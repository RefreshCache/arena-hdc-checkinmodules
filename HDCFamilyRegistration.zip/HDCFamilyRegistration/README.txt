To install this module go to your Administration->Modules section. From there you can import the Package.xml and it will load up the module into your Arena installation. After that you may create the page that will host the module anywhere you wish.

We do not automatically create a page for you as most people will likely have their page located differently than we do.